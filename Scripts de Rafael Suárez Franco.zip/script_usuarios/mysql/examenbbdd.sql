-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 14-12-2019 a las 14:01:54
-- Versión del servidor: 10.4.8-MariaDB
-- Versión de PHP: 7.3.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `dataaccess`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `disc_info`
--

CREATE TABLE `disc_info` (
  `title` varchar(30) NOT NULL,
  `total_duration` time DEFAULT NULL,
  `artist` varchar(30) NOT NULL,
  `main_genre` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `film_info`
--

CREATE TABLE `film_info` (
  `title` varchar(30) NOT NULL,
  `director` varchar(30) NOT NULL,
  `duration` time NOT NULL,
  `genre` varchar(30) DEFAULT NULL,
  `scripwriter` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `film_info`
--

INSERT INTO `film_info` (`title`, `director`, `duration`, `genre`, `scripwriter`) VALUES
('myfavfilm<3', 'idk', '03:00:10', 'action', 'scripter1'),
('this_film', 'asdf', '10:00:00', 'terror', 'Pepe');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `general_info`
--

CREATE TABLE `general_info` (
  `title` varchar(30) NOT NULL,
  `type` varchar(30) NOT NULL,
  `format` varchar(30) NOT NULL,
  `year` int(4) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `general_info`
--

INSERT INTO `general_info` (`title`, `type`, `format`, `year`) VALUES
('image2', 'image', 'jpg', 6000),
('myfavfilm<3', 'film', 'mpg', 2012),
('myimage', 'image', 'jpg', 1000),
('song1', 'song', 'mp3', NULL),
('this_film', 'film', 'mp4', 1000);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `image_info`
--

CREATE TABLE `image_info` (
  `title` varchar(30) NOT NULL,
  `author` varchar(30) NOT NULL,
  `size` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `image_info`
--

INSERT INTO `image_info` (`title`, `author`, `size`) VALUES
('image2', 'unknown', 1000),
('myimage', 'Me', 150);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `song_info`
--

CREATE TABLE `song_info` (
  `title` varchar(30) NOT NULL,
  `duration` time NOT NULL,
  `artist` varchar(30) NOT NULL,
  `genre` varchar(30) DEFAULT NULL,
  `disc_title` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `song_info`
--

INSERT INTO `song_info` (`title`, `duration`, `artist`, `genre`, `disc_title`) VALUES
('cancion1', '10:10:10', 'artista1', 'genero1', NULL);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `disc_info`
--
ALTER TABLE `disc_info`
  ADD PRIMARY KEY (`title`);

--
-- Indices de la tabla `film_info`
--
ALTER TABLE `film_info`
  ADD PRIMARY KEY (`title`),
  ADD KEY `title` (`title`);

--
-- Indices de la tabla `general_info`
--
ALTER TABLE `general_info`
  ADD PRIMARY KEY (`title`);

--
-- Indices de la tabla `image_info`
--
ALTER TABLE `image_info`
  ADD PRIMARY KEY (`title`);

--
-- Indices de la tabla `song_info`
--
ALTER TABLE `song_info`
  ADD PRIMARY KEY (`title`);

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `disc_info`
--
ALTER TABLE `disc_info`
  ADD CONSTRAINT `title` FOREIGN KEY (`title`) REFERENCES `general_info` (`title`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `film_info`
--
ALTER TABLE `film_info`
  ADD CONSTRAINT `title1` FOREIGN KEY (`title`) REFERENCES `general_info` (`title`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
