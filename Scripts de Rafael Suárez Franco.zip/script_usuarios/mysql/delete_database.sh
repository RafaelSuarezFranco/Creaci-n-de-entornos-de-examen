#/bin/bash
read -p "prefijo de las bbdd a borrar: " bd
read -p "usuarios a los que borramos la bbdd (usuarios.txt por defecto): " ficherousuario

defaultfile="../usuarios.txt"
if [ -z $ficherousuario] 
        then
                ficherousuario=$defaultfile
        fi

while IFS= read -r line; do
	user="$(echo $line |cut -f2 -d,)"
	userdatabase=$bd$user

	mysql -e "drop database $userdatabase;"
	mysql -e "drop user $user@'192.168.67.%';"

done < $ficherousuario

