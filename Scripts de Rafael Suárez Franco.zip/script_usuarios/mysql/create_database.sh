#/bin/bash
read -p "prefijo de la base de datos: " bd
read -p "fichero sql a importar: " ficherosql
read -p "usuarios que tendrán una base de datos (usuarios.txt por defecto): " ficherousuario

defaultfile="../usuarios.txt"
if [ -z $ficherousuario] 
        then
                ficherousuario=$defaultfile
        fi

while IFS= read -r line; do
	user="$(echo $line |cut -f2 -d,)"
	password="$(echo $line |cut -f4 -d,)"
	userdatabase=$bd$user

	mysql -e "create database $userdatabase;"
	mysql -u root $userdatabase < $ficherosql
	mysql -e "CREATE USER $user@'192.168.67.%' IDENTIFIED BY '$password';"
	mysql -e "GRANT ALL PRIVILEGES ON $userdatabase.* TO '$user'@'192.168.67.%';"
	mysql -e "FLUSH PRIVILEGES;"
	
done < $ficherousuario

