#!/bin/bash
defaultfile="usuarios.txt"
read -p "Seleccionar fichero con usuarios a borrar (dejar en blanco -> usuarios.txt):" fichero
if [ -z $fichero ] #si no se ha especificado un fichero
	then
		fichero=$defaultfile
	fi

#echo "borrando los usuarios:"
#cat $fichero |cut -f2 -d,


while IFS= read -r line; do
	user="$(echo $line |cut -f2 -d,)"
	userdel -f $user
	rm -rf /home/$user
done < $fichero

#borramos el contenido del fichero
cat /dev/null > $fichero


# Simplemente introducimos el fichero con los usuarios que queremos borrar. Se borrará el usuario
# y su directorio home con cualquier contenido que hubiera en él. El contenido del fichero de
# usuarios también será borrado.
