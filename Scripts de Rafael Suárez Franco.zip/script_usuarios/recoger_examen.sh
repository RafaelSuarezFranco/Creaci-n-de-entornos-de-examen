#!/bin/bash
defaultfolder="respuestas"
defaultfile="usuarios.txt"
read -p "Carpeta donde almacenar los exámenes: " carpeta
read -p "Fichero de usuarios a los que recogemos el examen (dejar en blanco -> usuarios.txt):" fichero
if [ -z $fichero ] 
        then
                fichero=$defaultfile
	fi
if [ -z $carpeta ]
	then 
		carpeta=$defaultfolder
	else
		mkdir $carpeta
	fi

while IFS= read -r line; do
	user="$(echo $line |cut -f2 -d,)"
	cp -r /home/$user/ $carpeta/
done < $fichero

