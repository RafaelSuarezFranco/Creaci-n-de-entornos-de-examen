#!/bin/bash
defaultfile="usuarios.txt"
read -p "Fichero del examen a repartir: " examen
read -p "Fichero de usuarios a los que se reparte el examen (dejar en blanco -> usuarios.txt):" fichero
if [ -z $fichero ] #si no se ha especificado un fichero
        then
                fichero=$defaultfile
        fi

while IFS= read -r line; do
	user="$(echo $line |cut -f2 -d,)"
	cp $examen /home/$user
done < $fichero

# Este script copiará un fichero de examen en el diretorio home de cada uno de los usuarios que 
# se encuentren en el fichero que especifiquemos.
