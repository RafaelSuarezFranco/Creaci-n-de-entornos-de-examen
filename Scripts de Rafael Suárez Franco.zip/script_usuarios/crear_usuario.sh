#!/bin/bash
defaultfile="usuarios.txt"
read -p "Cantidad de usuarios a crear: " usuarios
read -p "Crear fichero donde almacenar los usuarios (dejar en blanco -> usuarios.txt):" fichero
if [ -z $fichero ] #si no se ha especificado un fichero
	then
		fichero=$defaultfile
	else
		touch $fichero
	fi

for a in $(seq 1 $usuarios)

do
	user="$(cat /dev/urandom | tr -dc '[:alnum:]' | head -c 14; echo)"
	password="$(cat /dev/urandom | tr -dc '[:alnum:]' | head -c 14; echo)"
	echo "nombre,$user,contraseña,$password" >> $fichero
	useradd -m -p $(openssl passwd -1 $password) $user

#descomentar las siguientes líneas para restringir comandos del usuario.
#copiamos la carpeta de comandos en el home de cada usuario
#	cp /bin/comandos_permitidos /home/$user/comandos_permitidos
#	fichero_prof=”/home/$user/.bashrc”
#	touch $fichero_prof
#	echo “PATH=/home/$user/comandos_permitidos” >> $fichero_prof
#	echo “export PATH” >> $fichero_prof
#	echo “SHELL=/bin/rbash” >> $fichero_prof
#	echo “export SHELL” >> $fichero_prof

done

# Se recomienda ejecutar "sudo useradd -D -s /bin/bash" para que los nuevos usuarios use
# bash en lugar de sh.

# Instrucciones: ejecutar ./crear_usuario.sh (estando situado en el directorio del script)
# Introducir la cantidad de usuarios a crear
# Introducir, si se desea, el nombre del fichero donde se guardan los usuarios y contraseñas
# Por defecto se añadirán los nuevos usuarios a usuarios.txt, que se encuentra en el mismo directorio.
# Para cambiar la longitud del usuario o contraseña, modificar los números de las líneas 15 y 16.
# alnum arrojará caracteres en minúsculas, mayúsculas y números. Podemos sustituirlo por "alpha"
# para mayús. y minús., "lower" or "upper" para sólo minús. o sólo mayús. o "digit" para sólo números


# Recordar darle permisos de ejecución al propietario con "chmod u+x fichero.sh"
